package com.cts.chargeback.service;

import java.util.List;

import com.cts.chargeback.entity.User;

public interface UserService {
	void saveUser(User user);
	
	
}
